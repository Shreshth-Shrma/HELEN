# HELEN
The ongoing minor 1 project aimed at translating mute and deaf people's sign gestures
